#encoding=utf-8
import tensorflow.compat.v1 as tf
from keras.layers import Add, Concatenate, BatchNormalization, Input, Dense, LSTM, GRU, merge ,Conv1D,Dropout,Bidirectional,Multiply,MaxPooling1D,Flatten, Permute, Reshape
from keras.models import Model
from keras import backend as K
from attention_utils import get_activations,  get_data,get_data_recurrent
from keras.layers.core import Lambda, RepeatVector
from keras.layers import merge
from keras.layers.core import *

from keras.models import *
from keras import optimizers
import  pandas as pd
import  numpy as np
import matplotlib.pyplot as plt
import time


def divideTrainTest(dataset, rate = 0.3): 
  
    
    print (len(dataset))
  #  train_size = int(len(dataset) * (1-rate))
    test_size = int(len(dataset) * rate)
  
    train, test = dataset[: -test_size], dataset[-test_size:]#有时会需要-1
    print (len(train))
    print (len(test))       
    return train, test

def create_dataset(dataset, look_back):
    '''
    对数据进行处理
    '''
      
    
    dataX, dataY = [], []
    for i in range(len(dataset) - look_back):
        # 如果你想加pollution，下面就不要动
        # 如果不加，下面改成X.append(data[i:i + size, 1:])，然后下面fea_num=7       
        a = dataset[i:(i+look_back),1:]   #[i:(i+look_back),0:10] 前11列 
        dataX.append(a)
    #    X.append(data[i:i + size, :])
        dataY.append(dataset[i + look_back, 0])  # (dataset[i + look_back, 12]) 第12列RUL
    
    TrainX = np.array(dataX)
    Train_Y = np.array(dataY)

    return TrainX, Train_Y

#多维归一化  返回数据和最大最小值
def NormalizeMult(data):
    #normalize 用于反归一化
    data = np.array(data, dtype='float64')
    normalize = np.arange(2*data.shape[1],dtype='float64')

    normalize = normalize.reshape(data.shape[1],2)
    print(normalize.shape)
    for i in range(0,data.shape[1]):
        #第i列
        list = data[:,i]
        listlow,listhigh =  np.percentile(list, [0, 100])
        # print(i)
        normalize[i,0] = listlow
        normalize[i,1] = listhigh
        delta = listhigh - listlow
        if delta != 0:
            #第j行
            for j in range(0,data.shape[0]):
                data[j,i]  =  (data[j,i] - listlow)/delta
    #np.save("./normalize.npy",normalize)
    return  data, normalize

#多维反归一化
def FNormalizeMult(data,normalize):
    data = np.array(data)
    
   # print ("ata22",data.shape)
    for i in range(0,(data.shape[1])):
        listlow =  normalize[i,0]
        listhigh = normalize[i,1]
        delta = listhigh - listlow
        if delta != 0:
            #第j行
            for j in range(0,data.shape[0]):
                data[j,i]  =  data[j,i]*delta + listlow

    return data

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

def calcRMSE(true,pred):
    return np.sqrt(mean_squared_error(true, pred))


# 计算MAE
def calcMAE(true,pred):
    return mean_absolute_error(true, pred)


# 计算MAPE
def calcMAPE(true, pred, epsion = 0.0000000):

    true += epsion
    return np.sum(np.abs((true-pred)/true))/len(true)*100


# 计算SMAPE
def calcSMAPE(true, pred):
    delim = (np.abs(true)+np.abs(pred))/2.0
    return np.sum(np.abs((true-pred)/delim))/len(true)*100

def calcR2(true, pred):
    return r2_score (true, pred)


    
    

def model(INPUT_DIMS, lookBack, filters, kernel_size, hidden_dim, lr):
    
    inputs = Input(shape=(lookBack, INPUT_DIMS))
      

#######BiGRU
    x = LSTM(hidden_dim, return_sequences=False, name='LSTM')(inputs)  #return_sequences=True是否需要调整
   # x5 = Dropout(0.2)(x5)

 
    output = Dense(1)(x) #
  
       
    model = Model(inputs=[inputs], outputs=output)
          
            
    return model
    
                       


def attention_model(data, INPUT_DIMS, lookBack, epochs, batchSize, filters, kernel_size, hidden_dim, lr):
    
    
    #归一化
#    data, normalize = NormalizeMult(data)
#    
#    train, test = divideTrainTest(data)
#    
#    
#    train_X, train_Y = create_dataset(train, TIME_STEPS)
#    test_X, test_Y = create_dataset(test, TIME_STEPS)
#    
    
    train, test = divideTrainTest(data)
    train, normalize = NormalizeMult(train)
    test, normalize1 = NormalizeMult(test)
    
    
    train_X, train_Y = create_dataset(train, TIME_STEPS)
    test_X, test_Y = create_dataset(test, TIME_STEPS)
   
   
 
    print("trainX shape is", train_X.shape)
    print("trainY shape is", train_Y.shape)
    print("testX shape is", test_X.shape)
    print("testY shape is", test_Y.shape)
    
    print(len(train_X))
    print(train_X.shape,train_Y.shape)

    print(len(test_X))
    print(test_X.shape,test_Y.shape)
     
    t1 = time.time()
    m = model(INPUT_DIMS, lookBack, filters, kernel_size, hidden_dim, lr)
    m.summary()
    opt = optimizers.Adam(lr=lr)
    m.compile(optimizer= opt, loss='mean_squared_error', metrics=["mean_absolute_percentage_error"])
    m.fit([train_X], train_Y, epochs= epochs, batch_size=batchSize)
    t2 = time.time()-t1
    print("runtime:",t2)
     
 
    trainPred = m.predict(train_X)
    t3 = time.time()
    testPred = m.predict(test_X)
    t4 = time.time()-t3
    print("runtime:",t4)
   # testPred = m.predict(test_X)
    trainPred = trainPred.reshape(-1, 1)
    testPred = testPred.reshape(-1, 1)
    
    
    
    trainPred = FNormalizeMult(trainPred, normalize)
    train_Y = train_Y.reshape(-1, 1)
    train_Y = FNormalizeMult(train_Y, normalize)
    

    testPred = FNormalizeMult(testPred, normalize1)
    test_Y = test_Y.reshape(-1, 1)
    test_Y = FNormalizeMult(test_Y, normalize1)
    
    # 绘制损失函数
  

#    plt.figure(figsize=(20, 8))
#    plt.xticks(fontsize=22)
#    plt.yticks(fontsize=22)
#   
#    plt.xlabel(u"Number of Samples", size=28) #x轴标签
#    plt.ylabel("TTAF (x 30s)",size=28) #Y轴标签
#    #  plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #Y轴标签
#    
#    
#    plt.plot([x for x in train_Y],c='b', linewidth=1)
#    plt.plot([x for x in trainPred],c='g', linewidth=3)
#        # plt.vlines(191, 0, 95, colors = "k",linewidth=4,linestyles = "dashed")
#    plt.plot([None for _ in train_Y]+[x for x in test_Y],c='b', linewidth=1)
#    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)
#    

    MAE = calcMAE(test_Y, testPred)
    print(MAE)
    RMSE = calcRMSE(test_Y, testPred)
    print(RMSE)
    r2_score = calcR2(test_Y, testPred)
    print(r2_score)
          
    return trainPred, testPred, MAE, RMSE, r2_score


def load_data(filename, columnName):

    df = pd.read_csv(filename)
    df = df.fillna(0)
    ts = df[columnName]
    data = ts.values.reshape(-1, 1).astype("float32")  # (N, 1)
    print("time series shape:", data.shape)
    return data


if __name__ == "__main__":
   #加载数据

  #  data = pd.read_csv("./Android/RUL1t4.csv")
    data = pd.read_csv("./OpenStack/30s/RUL_o4t2.csv") 


    print(data.columns)
    print(data.shape)

    INPUTDIMS = 10 #Android:13, OpenStack:10
    TIME_STEPS = 20 #固定 20
 
    hidden_dim = 32 #固定 32
    #lstm_units = 32
    Epochs = 100 # 固定 100
    Batch_size = 32 #默认
    Filters = 64    #默认
    Kernel_size = 3 #默认
    lr = 1e-3  #默认
   

    trainPred, testPred, mae, rmse, r2 = attention_model(data, INPUT_DIMS = INPUTDIMS,
                                                                  lookBack=TIME_STEPS, epochs = Epochs, 
                                                                  batchSize=Batch_size, filters = Filters, 
                                                                  kernel_size = Kernel_size, hidden_dim=hidden_dim, lr=lr)




